package cuenta;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class ServidorCuentas {
	public static void main(String args[]) 
	{ 
		try
		{ 
			CuentaRMII obj = new ManejadorCuentas(); 
			LocateRegistry.createRegistry(1900); 
			Naming.rebind("rmi://localhost:1900" + "/ManejadorCuentas",obj); 
			System.out.println("Servidor de cuentas corriendo");
		} 
		catch(Exception ae) 
		{ 
			System.out.println(ae); 
		} 
	} 
}
