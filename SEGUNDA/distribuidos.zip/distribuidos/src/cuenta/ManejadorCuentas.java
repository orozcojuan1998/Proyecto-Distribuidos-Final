package cuenta;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.charset.StandardCharsets;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import cliente.Cliente;

public class ManejadorCuentas extends UnicastRemoteObject implements CuentaRMII {
	
	private static final long serialVersionUID = 1L;
	private static ArrayList<Cuenta> cuentas= new ArrayList<Cuenta>();
	private static Scanner reader = new Scanner(System.in);

	public ManejadorCuentas() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void cargarCuentas(Cuenta cuenta) throws RemoteException {
		this.cuentas.add(cuenta);
		this.guardarCuentas(cuentas);
	}
	@Override
	public List<Cuenta> getListaCuentas() throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void imprimirCuentas() throws RemoteException {
		// TODO Auto-generated method stub
		for (Cuenta cuenta : cuentas) {
			System.out.println(cuenta.toString());
		}
		
	}


	public String bytesToHex(byte[] hash) {
		  StringBuffer hexString = new StringBuffer();
		    for (int i = 0; i < hash.length; i++) {
		        String hex = Integer.toHexString(0xff & hash[i]);
		        if(hex.length() == 1) hexString.append('0');
		            hexString.append(hex);
		    }
		    return hexString.toString();
	}
	
	public String hashearContra(String value) {
		MessageDigest digest;
		try {
			digest = MessageDigest.getInstance("SHA-256");
			 byte[] encodedhash = digest.digest(value.getBytes(StandardCharsets.UTF_8));
		      String hash = bytesToHex(encodedhash);
		      return hash;
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
	
	
	
	private static void guardarCuentas(ArrayList<Cuenta> cuentas){
		try{
			System.out.println("Abriendo archivo config.");
			File config = new File("configuracion\\Cuentas.obj");
			if(!config.exists()){
				System.out.println("Creando archivo config.");
				config.createNewFile();
			}
			FileOutputStream fileOut = new FileOutputStream(config);
			ObjectOutputStream salida = new ObjectOutputStream(fileOut);
			salida.writeObject(cuentas);
			salida.close();
			System.out.println("Config guardado.");
		}catch(Exception e){
			System.err.println("Guardando objeto cuentas de BDCuentas: " + e.toString());
			e.printStackTrace();
		}
	}
	
	@Override
	public boolean autenticarUsuario(String usuario, String contrasena) throws RemoteException, NoSuchAlgorithmException {
		Cuenta cuenta = this.buscarCuenta(usuario);
		System.out.println("cuentaaa "+cuenta.toString());
		if(cuenta != null){
			if(cuenta.validarContrasena(contrasena)){
				guardarCuentas(cuentas);
				return true;
			}
			System.out.println("Validado incorrecto");
			return false;
		}
		return false;
	}

	@Override
	public Cuenta buscarCuenta(String usuario) {
		System.out.println("Buscado cuentas...");
		System.out.println(cuentas);
		for(Cuenta cuenta:cuentas){
			System.out.println(cuenta.getUsuario()+"--"+usuario);
	          if(cuenta.getUsuario().equals(usuario)){
	              return cuenta;
	          }
	      }
	      return null;
	}

}
