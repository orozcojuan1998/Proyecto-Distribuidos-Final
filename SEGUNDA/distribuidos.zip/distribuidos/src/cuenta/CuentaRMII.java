package cuenta;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import producto.Producto;

public interface CuentaRMII extends Remote {
	public void cargarCuentas(Cuenta cuenta) throws RemoteException;
	public List<Cuenta> getListaCuentas() throws RemoteException;
	public void imprimirCuentas() throws RemoteException;
	public boolean autenticarUsuario(String usuario,String contrasena) throws RemoteException, NoSuchAlgorithmException;
	public Cuenta buscarCuenta(String usuario)throws RemoteException;
}
