package cuenta;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.nio.charset.StandardCharsets;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import producto.ManejadorProductos;
import producto.Producto;
import producto.ProductoRMII;

public class Cuenta implements Serializable{


	private static CuentaRMII interfac;
	public static void main(String[] args) throws MalformedURLException, RemoteException, NotBoundException, NoSuchAlgorithmException {
		interfac = (CuentaRMII) Naming.lookup("rmi://localhost:1900/ManejadorCuentas");
		try {
			String linea;
			try {
				FileReader fr = new FileReader("iniciocuentas.txt");
				BufferedReader br = new BufferedReader(fr);
				linea = br.readLine();
				linea = br.readLine();
				int nCuentas=Integer.parseInt(linea);
				for(int i=0;i<nCuentas;i++) {
					linea = br.readLine();
					String[] parts = linea.split(",");
					MessageDigest digest = MessageDigest.getInstance("SHA-256");
                    byte[] encodedhash = digest.digest(parts[0].getBytes(StandardCharsets.UTF_8));
                    String hash = bytesToHex(encodedhash);
                    digest = MessageDigest.getInstance("SHA-256");
                    encodedhash = digest.digest(parts[3].getBytes(StandardCharsets.UTF_8));
                    String hash2 = bytesToHex(encodedhash);
					Cuenta cuenta= new Cuenta(hash, Float.parseFloat(parts[1]),parts[2],hash2);
					interfac.cargarCuentas(cuenta);
				}
				br.close();
				interfac.imprimirCuentas();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		} catch (IOException e){System.out.println("readline:"+e.getMessage());
		}

	}
	  private static String bytesToHex(byte[] hash) {
          
		  StringBuffer hexString = new StringBuffer();
          for (int i = 0; i < hash.length; i++) {
              String hex = Integer.toHexString(0xff & hash[i]);
              if(hex.length() == 1) hexString.append('0');
                  hexString.append(hex);
          }
          return hexString.toString();
      }
	public String usuario;
	public String contrasena;
	public String tarjeta;
	public float saldo;
	
	public boolean validarContrasena(String con) throws RemoteException, NoSuchAlgorithmException{
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] encodedhash = digest.digest(con.getBytes(StandardCharsets.UTF_8));
        String hash = bytesToHex(encodedhash);
		if(this.contrasena.equals(hash))
			return true;
		return false;
	}
	
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getContrasena() {
		return contrasena;
	}
	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}
	public String getTarjeta() {
		return tarjeta;
	}
	public void setTarjeta(String tarjeta) {
		this.tarjeta = tarjeta;
	}
	public float getSaldo() {
		return saldo;
	}
	public void setSaldo(float saldo) {
		this.saldo = saldo;
	}
	
	public Cuenta(String tarjeta, float saldo,String usuario, String contrasena) {
		super();
		this.usuario = usuario;
		this.contrasena = contrasena;
		this.tarjeta = tarjeta;
		this.saldo = saldo;
	}
	@Override
	public String toString() {
		return "Cuenta [usuario=" + usuario + ", contrasena=" + contrasena + ", tarjeta=" + tarjeta + ", saldo=" + saldo
				+ "]";
	}
	
}
	
