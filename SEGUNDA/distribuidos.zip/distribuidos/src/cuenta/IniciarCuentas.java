package cuenta;

import java.util.ArrayList;
import java.util.Scanner;

public class IniciarCuentas extends Thread{
	private boolean continuar=true;
	private static ArrayList<Cuenta> cuentas;
	  IniciarCuentas(ArrayList<Cuenta> cuent){
	    cuentas = cuent;
	  }
	
	public void run()
	   {
	     Scanner reader = new Scanner(System.in);
	     int num;
	      while (continuar)
	      {
	        do{
	        	System.out.println("Menu Servidor de cuentas.");
				System.out.println("1. Mostrar datos de las cuentas.");
				System.out.println("2. Salir.");
						num = reader.nextInt();
						switch(num){
							case 1:
								imprimirCuentas();
							break;
							default:
								System.out.println("Ingrese una opci�n v�lida");
							break;
						}
					}while(num != 2);
	      }
	   }
	
	 public static void imprimirCuentas(){
	     for(Cuenta cuenta:cuentas){
	         System.out.println(cuenta.toString());
	     }
	   }
}	
