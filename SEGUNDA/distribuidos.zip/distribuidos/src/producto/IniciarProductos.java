package producto;

import java.util.ArrayList;
import java.util.Scanner;

public class IniciarProductos extends Thread{
	private boolean continuar=true;
	private static ArrayList<Producto> productos;
	  IniciarProductos(ArrayList<Producto> produc){
	    productos = produc;
	  }
	  public void stopMenu()
	   {
	      continuar=false;
	   }
	public void run()
	   {
	     Scanner reader = new Scanner(System.in);
	     int num;
	      while (continuar)
	      {
	        do{
						System.out.println("Menu Servidor de Productos.");
						System.out.println("1. Mostrar productos.");
						System.out.println("2. Salir.");
						num = reader.nextInt();
						switch(num){
							case 1:
								imprimirProductos();
							break;
							case 2:
					             this.stopMenu();
							default:
								System.out.println("Ingrese una opci�n v�lida");
							break;
						}
					}while(num != 2);
	      }
	   }
	
	 public static void imprimirProductos(){
	     for(Producto producto:productos){
	         System.out.println(producto.toString());
	     }
	   }
}	
