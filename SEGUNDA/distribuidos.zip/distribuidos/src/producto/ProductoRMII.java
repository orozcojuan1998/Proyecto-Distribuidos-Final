package producto;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

public interface ProductoRMII extends Remote {
	public void cargarProductos(Producto producto) throws RemoteException;
	public String comprarProducto(String producto, int cantProductos) throws RemoteException;
	public List<Producto> getListaProductos() throws RemoteException;
	public void imprimirProductos() throws RemoteException;
}
