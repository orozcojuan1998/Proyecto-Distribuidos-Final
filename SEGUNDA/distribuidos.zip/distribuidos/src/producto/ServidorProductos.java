package producto;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

import cuenta.CuentaRMII;
import cuenta.ManejadorCuentas;

public class ServidorProductos {
	public static void main(String args[]) 
	{ 
		try
		{ 
			ProductoRMII obj = new ManejadorProductos(); 
			LocateRegistry.createRegistry(1400); 
			Naming.rebind("rmi://localhost:1400" + "/ManejadorProductos",obj); 
			System.out.println("Servidor de productos corriendo");
			
		} 
		catch(Exception ae) 
		{ 
			System.out.println(ae); 
		} 
	} 
}
