package producto;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Semaphore;


public class ManejadorProductos extends UnicastRemoteObject implements ProductoRMII {

	public ManejadorProductos() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	private static final long uid = 1L;
    private static ArrayList<Producto> productos = new  ArrayList<Producto>();
	private static Scanner reader = new Scanner(System.in);
	private final Semaphore pcompras = new Semaphore (1);
	
	
	@Override
	public void cargarProductos(Producto producto) throws RemoteException {
		this.productos.add(producto);
		this.guardarProductos(productos);
	}

	@Override
	public String comprarProducto(String producto, int cantProductos) throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Producto> getListaProductos() throws RemoteException {
		return productos;
	}

	@Override
	public void imprimirProductos() throws RemoteException {
		System.out.println("PRODUCTOS "+this.productos.size());
		for (Producto producto : productos) {
			System.out.println(producto.toString());
		}
	}

	
	public static void guardarProductos(ArrayList<Producto> productos) throws RemoteException {
		try{
			System.out.println("Abriendo archivo config.");
			File config = new File("configuracion\\Productos.obj");
			if(!config.exists()){
				System.out.println("Creando archivo config.");
				config.createNewFile();
			}
			FileOutputStream fileOut = new FileOutputStream(config);
			ObjectOutputStream salida = new ObjectOutputStream(fileOut);
			salida.writeObject(productos);
			salida.close();
			System.out.println("Config guardado.");
		}catch(Exception e){
			System.err.println("Guardando objeto cuentas de BDCuentas: " + e.toString());
			e.printStackTrace();
		}
		
	}


}
