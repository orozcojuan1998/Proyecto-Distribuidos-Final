package producto;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import cuenta.CuentaRMII;

public class Producto implements Serializable{

	private static ProductoRMII interfac;
	public static void main(String[] args) throws MalformedURLException, RemoteException, NotBoundException {
		interfac = (ProductoRMII) Naming.lookup("rmi://localhost:1400/ManejadorProductos");
		try {
			String linea;
			try {
				FileReader fr = new FileReader("inicioproductos.txt");
				BufferedReader br = new BufferedReader(fr);
				linea = br.readLine();
				linea = br.readLine();
				int nProductos=Integer.parseInt(linea);
				for(int i=0;i<nProductos;i++) {
					linea = br.readLine();
					String[] parts = linea.split(",");
					Producto producto= new Producto(parts[0], Float.parseFloat(parts[1]),Integer.parseInt(parts[2]));
					interfac.cargarProductos(producto);
				}
				br.close();
				interfac.imprimirProductos();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		} catch (IOException e){System.out.println("readline:"+e.getMessage());
		}

	}


	public String nombre;
	public int cantidadDisponible;
	public float precio;

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getCantidadDisponible() {
		return cantidadDisponible;
	}
	public void setCantidadDisponible(int cantidadDisponible) {
		this.cantidadDisponible = cantidadDisponible;
	}
	public float getPrecio() {
		return precio;
	}
	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public Producto(String nombre, float precio, int cantidadDisponible) {
		super();
		this.nombre = nombre;
		this.cantidadDisponible = cantidadDisponible;
		this.precio = precio;
	}
	@Override
	public String toString() {
		return "Producto [nombre=" + nombre + ", cantidadDisponible=" + cantidadDisponible + ", precio=" + precio + "]";
	}

}
